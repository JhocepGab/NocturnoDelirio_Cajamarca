namespace GUI
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.GroupBox gCuenta;
        private System.Windows.Forms.TextBox txtDNI;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.ComboBox cmbPlan;
        private System.Windows.Forms.TextBox txtTarjeta;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.ListBox lbUsuarios;
        private System.Windows.Forms.GroupBox gRes;
        private System.Windows.Forms.ComboBox cmbAnfitriona;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.RadioButton rb30;
        private System.Windows.Forms.RadioButton rb60;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Button btnRes;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.ListBox lbCitas;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gCuenta = new System.Windows.Forms.GroupBox();
            this.txtDNI = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.cmbPlan = new System.Windows.Forms.ComboBox();
            this.txtTarjeta = new System.Windows.Forms.TextBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lbUsuarios = new System.Windows.Forms.ListBox();
            this.gRes = new System.Windows.Forms.GroupBox();
            this.cmbAnfitriona = new System.Windows.Forms.ComboBox();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.rb30 = new System.Windows.Forms.RadioButton();
            this.rb60 = new System.Windows.Forms.RadioButton();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.btnVer = new System.Windows.Forms.Button();
            this.btnRes = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.lbCitas = new System.Windows.Forms.ListBox();
            this.gCuenta.SuspendLayout();
            this.gRes.SuspendLayout();
            this.SuspendLayout();
            // 
            // gCuenta
            // 
            this.gCuenta.Controls.Add(this.btnLogin);
            this.gCuenta.Controls.Add(this.btnRegistrar);
            this.gCuenta.Controls.Add(this.txtTarjeta);
            this.gCuenta.Controls.Add(this.cmbPlan);
            this.gCuenta.Controls.Add(this.txtPassword);
            this.gCuenta.Controls.Add(this.txtEmail);
            this.gCuenta.Controls.Add(this.txtNombre);
            this.gCuenta.Controls.Add(this.txtDNI);
            this.gCuenta.Location = new System.Drawing.Point(12, 12);
            this.gCuenta.Name = "gCuenta";
            this.gCuenta.Size = new System.Drawing.Size(300, 220);
            this.gCuenta.TabIndex = 0;
            this.gCuenta.TabStop = false;
            this.gCuenta.Text = "Cuenta";
            // 
            // txtDNI
            // 
            this.txtDNI.Location = new System.Drawing.Point(80, 22);
            this.txtDNI.MaxLength = 8;
            this.txtDNI.Name = "txtDNI";
            this.txtDNI.Size = new System.Drawing.Size(100, 20);
            this.txtDNI.TabIndex = 0;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(80, 52);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(200, 20);
            this.txtNombre.TabIndex = 1;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(80, 82);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(200, 20);
            this.txtEmail.TabIndex = 2;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(80, 112);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(200, 20);
            this.txtPassword.TabIndex = 3;
            // 
            // cmbPlan
            // 
            this.cmbPlan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPlan.FormattingEnabled = true;
            this.cmbPlan.Items.AddRange(new object[] {
            "Gratis",
            "Premium (S/.50)",
            "VIP (S/.100)"});
            this.cmbPlan.Location = new System.Drawing.Point(80, 142);
            this.cmbPlan.Name = "cmbPlan";
            this.cmbPlan.Size = new System.Drawing.Size(200, 21);
            this.cmbPlan.TabIndex = 4;
            // 
            // txtTarjeta
            // 
            this.txtTarjeta.Location = new System.Drawing.Point(80, 172);
            this.txtTarjeta.MaxLength = 16;
            this.txtTarjeta.Name = "txtTarjeta";
            this.txtTarjeta.Size = new System.Drawing.Size(200, 20);
            this.txtTarjeta.TabIndex = 5;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(10, 198);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(90, 23);
            this.btnRegistrar.TabIndex = 6;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.BtnRegistrar_Click);
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(110, 198);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(90, 23);
            this.btnLogin.TabIndex = 7;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // lbUsuarios
            // 
            this.lbUsuarios.FormattingEnabled = true;
            this.lbUsuarios.Location = new System.Drawing.Point(12, 238);
            this.lbUsuarios.Name = "lbUsuarios";
            this.lbUsuarios.Size = new System.Drawing.Size(300, 199);
            this.lbUsuarios.TabIndex = 1;
            // 
            // gRes
            // 
            this.gRes.Controls.Add(this.lbCitas);
            this.gRes.Controls.Add(this.btnUndo);
            this.gRes.Controls.Add(this.btnRes);
            this.gRes.Controls.Add(this.btnVer);
            this.gRes.Controls.Add(this.lblPrecio);
            this.gRes.Controls.Add(this.rb60);
            this.gRes.Controls.Add(this.rb30);
            this.gRes.Controls.Add(this.txtHora);
            this.gRes.Controls.Add(this.dtpFecha);
            this.gRes.Controls.Add(this.cmbAnfitriona);
            this.gRes.Location = new System.Drawing.Point(318, 12);
            this.gRes.Name = "gRes";
            this.gRes.Size = new System.Drawing.Size(550, 260);
            this.gRes.TabIndex = 2;
            this.gRes.TabStop = false;
            this.gRes.Text = "Reserva";
            // 
            // cmbAnfitriona
            // 
            this.cmbAnfitriona.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAnfitriona.FormattingEnabled = true;
            this.cmbAnfitriona.Items.AddRange(new object[] {
            "Valeria",
            "Camila",
            "Kiara",
            "Luna",
            "Abril",
            "Mia",
            "Zoe",
            "Dana"});
            this.cmbAnfitriona.Location = new System.Drawing.Point(16, 25);
            this.cmbAnfitriona.Name = "cmbAnfitriona";
            this.cmbAnfitriona.Size = new System.Drawing.Size(200, 21);
            this.cmbAnfitriona.TabIndex = 0;
            // 
            // dtpFecha
            // 
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Location = new System.Drawing.Point(230, 25);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(100, 20);
            this.dtpFecha.TabIndex = 1;
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(346, 25);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(60, 20);
            this.txtHora.TabIndex = 2;
            this.txtHora.Text = "20:00";
            // 
            // rb30
            // 
            this.rb30.AutoSize = true;
            this.rb30.Location = new System.Drawing.Point(16, 60);
            this.rb30.Name = "rb30";
            this.rb30.Size = new System.Drawing.Size(86, 17);
            this.rb30.TabIndex = 3;
            this.rb30.TabStop = true;
            this.rb30.Text = "30 min (30)";
            this.rb30.UseVisualStyleBackColor = true;
            this.rb30.CheckedChanged += new System.EventHandler(this.RbDuracion_CheckedChanged);
            // 
            // rb60
            // 
            this.rb60.AutoSize = true;
            this.rb60.Location = new System.Drawing.Point(120, 60);
            this.rb60.Name = "rb60";
            this.rb60.Size = new System.Drawing.Size(92, 17);
            this.rb60.TabIndex = 4;
            this.rb60.TabStop = true;
            this.rb60.Text = "60 min (60)";
            this.rb60.UseVisualStyleBackColor = true;
            this.rb60.CheckedChanged += new System.EventHandler(this.RbDuracion_CheckedChanged);
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(230, 62);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(73, 13);
            this.lblPrecio.TabIndex = 5;
            this.lblPrecio.Text = "Precio: S/. 0";
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(16, 90);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(75, 23);
            this.btnVer.TabIndex = 6;
            this.btnVer.Text = "Verificar";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.BtnVer_Click);
            // 
            // btnRes
            // 
            this.btnRes.Location = new System.Drawing.Point(97, 90);
            this.btnRes.Name = "btnRes";
            this.btnRes.Size = new System.Drawing.Size(75, 23);
            this.btnRes.TabIndex = 7;
            this.btnRes.Text = "Reservar";
            this.btnRes.UseVisualStyleBackColor = true;
            this.btnRes.Click += new System.EventHandler(this.BtnRes_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Location = new System.Drawing.Point(178, 90);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(75, 23);
            this.btnUndo.TabIndex = 8;
            this.btnUndo.Text = "Deshacer";
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.BtnUndo_Click);
            // 
            // lbCitas
            // 
            this.lbCitas.FormattingEnabled = true;
            this.lbCitas.Location = new System.Drawing.Point(16, 130);
            this.lbCitas.Name = "lbCitas";
            this.lbCitas.Size = new System.Drawing.Size(520, 108);
            this.lbCitas.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 450);
            this.Controls.Add(this.gRes);
            this.Controls.Add(this.lbUsuarios);
            this.Controls.Add(this.gCuenta);
            this.Name = "Form1";
            this.Text = "Nocturno Delirio";
            this.gCuenta.ResumeLayout(false);
            this.gCuenta.PerformLayout();
            this.gRes.ResumeLayout(false);
            this.gRes.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}
